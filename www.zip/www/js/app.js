/* ===============================
   IMPORTS
================================ */
import { borrarBaseDeDatos } from './db/sqlite.js';
import { setEmpresaActiva, listarEmpresas } from './services/empresas.service.js';


import { initSidebar } from './ui/sidebar.js';
import { initSchema } from './db/schema.js';

import {
  seedEmpresas,
  seedCultivos,
  seedTecnicos,
  seedTiposAplicacion,
  seedCaudales,
  seedTiposProducto,
  seedUnidadesMedida,
} from './db/seed.js';

// Views
import { cargarEmpresas } from './views/empresas.view.js';
import { initCultivosView, cargarCultivos } from './views/cultivos.view.js';
import { initTecnicosView, cargarTecnicos } from './views/tecnicos.view.js';
import { initCaudalesView, cargarCaudales } from './views/caudales.view.js';
import { initSectoresView } from './views/sectores.view.js';
import { initLotesView, cargarVistaLotes } from './views/lotes.view.js';
import { initVariedadesView, cargarVistaVariedades } from './views/variedades.view.js';
import { initProductosView, cargarProductos } from './views/productos.view.js';
import { initTiposProductoView, cargarTiposProducto } from './views/tiposProducto.view.js';
import { initTiposAplicacionView, cargarTiposAplicacion } from './views/tiposAplicacion.view.js';
import { initUnidadesMedidaView, cargarUnidadesMedida } from './views/unidadesMedida.view.js';
import { initNuevaHojaView, cargarNuevaHoja } from './views/hojaNueva.view.js';
import { initHojaDetalleView, cargarHojaDetalle } from './views/hojaDetalle.view.js';
import { initHojasView, cargarHojas } from './views/hojas.view.js';
import { initHojaEditarView, cargarHojaEditar } from './views/hojaEditar.view.js';
import { initImportacionView, cargarImportacion } from './views/importacion.view.js';

function ocultarSplash() {
  const splash = document.getElementById('splash-screen');
  if (!splash) return;
  splash.classList.add('splash-hide');
  splash.addEventListener('transitionend', () => splash.remove(), { once: true });
}

/* ===============================
   TIPOS DE USO
================================ */
const TIPOS_USO = [
  {
    id: 'agroquimicos',
    nombre: 'Descargo de Agroquímicos',
    icono: '🧪',
    sub: 'Hojas de trabajo',
    disponible: true,
  },
  {
    id: 'cana',
    nombre: 'Plantación de Caña',
    icono: '🌾',
    sub: 'Próximamente',
    disponible: false,
  },
];

let tipoUsoActivo = null;

function getTipoUsoActivo() { return tipoUsoActivo; }
window.getTipoUsoActivo = getTipoUsoActivo;

/* ===============================
   SELECCIÓN DE PROPIEDAD
================================ */
async function mostrarSelectorPropiedad(empresas) {
  return new Promise(resolve => {
    const screen = document.getElementById('propiedad-screen');
    const cards  = document.getElementById('propiedad-cards');

    cards.innerHTML = empresas.map(e => `
      <div class="propiedad-card" data-id="${e.id}">
        <div class="propiedad-card-icon">🏡</div>
        <div class="propiedad-card-info">
          <div class="propiedad-card-nombre">${e.nombre}</div>
          <div class="propiedad-card-sub">Propiedad</div>
        </div>
        <div class="propiedad-card-arrow">›</div>
      </div>
    `).join('');

    screen.classList.remove('hidden');

    cards.querySelectorAll('.propiedad-card').forEach(card => {
      card.addEventListener('click', () => {
        const id = card.dataset.id;
        const empresa = empresas.find(e => String(e.id) === String(id));
        setEmpresaActiva(empresa);

        screen.classList.add('propiedad-hide');
        screen.addEventListener('transitionend', () => {
          screen.remove();
          actualizarHeaderPropiedad(empresa.nombre);
          resolve(empresa);
        }, { once: true });
      });
    });
  });
}

async function initApp() {
  try {
  
    //await borrarBaseDeDatos();
    
    await initSchema();

    await seedEmpresas();
    await seedCultivos();
    await seedTiposAplicacion();
    await seedCaudales();
    await seedTiposProducto();
    await seedUnidadesMedida();
    await seedTecnicos();
    //await seedVariedades();
    //await seedSectoresDemo();
    //await seedLotesDemo();
    //await seedProductos();
    //await seedProductosUnidades();

    initSidebar();
    initHojasView();
    await cargarHojas();

    // Mínimo 1.8 s de splash → luego mostrar selector de propiedad
    setTimeout(async () => {
      ocultarSplash();

      const empresas = await listarEmpresas();

      // Si solo hay una empresa, seleccionarla automáticamente sin preguntar
      if (empresas.length === 1) {
        setEmpresaActiva(empresas[0]);
        actualizarHeaderPropiedad(empresas[0].nombre);
        await mostrarSelectorUso(empresas[0]);
        return;
      }

      // Siempre mostrar el selector para que el usuario elija
      const empresa = await mostrarSelectorPropiedad(empresas);
      await mostrarSelectorUso(empresa);

    }, 1800);

  } catch (e) {
    console.error('[APP] ❌ Error fatal:', e);
    ocultarSplash();
    alert(e.message);
  }
}

/* ===============================
   SELECCIÓN DE TIPO DE USO
================================ */
function crearUsoScreen() {
  let screen = document.getElementById('uso-screen');
  if (!screen) {
    screen = document.createElement('div');
    screen.id = 'uso-screen';
    screen.innerHTML = `
      <div class="splash-bg-ring splash-ring-1"></div>
      <div class="splash-bg-ring splash-ring-2"></div>
      <div class="splash-bg-ring splash-ring-3"></div>
      <div class="propiedad-content">
        <div class="uso-propiedad-badge" id="uso-propiedad-badge">🏡</div>
        <div class="splash-texts">
          <div class="splash-name">¿Qué vas a hacer?</div>
          <div class="splash-tagline">Seleccioná el tipo de uso</div>
        </div>
        <div class="propiedad-cards" id="uso-cards"></div>
      </div>
    `;
    document.body.prepend(screen);
  }
  return screen;
}

async function mostrarSelectorUso(empresa) {
  return new Promise(resolve => {
    const screen = crearUsoScreen();
    const cards  = document.getElementById('uso-cards');

    // Mostrar badge con nombre de la propiedad
    const badge = document.getElementById('uso-propiedad-badge');
    if (badge) badge.textContent = `🏡 ${empresa.nombre}`;

    cards.innerHTML = TIPOS_USO.map(t => `
      <div class="propiedad-card ${!t.disponible ? 'propiedad-card--disabled' : ''}" data-id="${t.id}" ${!t.disponible ? 'aria-disabled="true"' : ''}>
        <div class="propiedad-card-icon">${t.icono}</div>
        <div class="propiedad-card-info">
          <div class="propiedad-card-nombre">${t.nombre}</div>
          <div class="propiedad-card-sub">${t.sub}</div>
        </div>
        <div class="propiedad-card-arrow">${t.disponible ? '›' : '🔒'}</div>
      </div>
    `).join('');

    screen.classList.remove('hidden', 'propiedad-hide');

    cards.querySelectorAll('.propiedad-card:not(.propiedad-card--disabled)').forEach(card => {
      card.addEventListener('click', () => {
        const uso = TIPOS_USO.find(t => t.id === card.dataset.id);
        tipoUsoActivo = uso;

        screen.classList.add('propiedad-hide');
        screen.addEventListener('transitionend', () => {
          screen.remove();
          actualizarHeaderUso(uso);
          resolve(uso);
        }, { once: true });
      });
    });
  });
}

async function cambiarUso() {
  const empresa = getEmpresaActiva();
  if (!empresa) return;

  const screen = crearUsoScreen();
  screen.classList.remove('hidden', 'propiedad-hide');

  document.getElementById('sidebar')?.classList.remove('open');
  document.getElementById('overlay')?.classList.remove('active');

  await mostrarSelectorUso(empresa);
  window.showView('hojas');
}

window.cambiarUso = cambiarUso;

function actualizarHeaderUso(uso) {
  const header = document.querySelector('.header-title');
  const empresa = getEmpresaActiva();
  if (header && empresa) {
    header.textContent = `${uso.icono} ${empresa.nombre} · ${uso.nombre}`;
  }
  const sidebarUso = document.getElementById('sidebar-uso-nombre');
  if (sidebarUso) sidebarUso.textContent = uso.nombre;
}

async function cambiarPropiedad() {
  const empresas = await listarEmpresas();
  if (empresas.length <= 1) return;

  // Recrear la pantalla de selección
  let screen = document.getElementById('propiedad-screen');
  if (!screen) {
    screen = document.createElement('div');
    screen.id = 'propiedad-screen';
    screen.innerHTML = `
      <div class="splash-bg-ring splash-ring-1"></div>
      <div class="splash-bg-ring splash-ring-2"></div>
      <div class="splash-bg-ring splash-ring-3"></div>
      <div class="propiedad-content">
        <div class="splash-logo-wrap"><div class="splash-logo">🌱</div></div>
        <div class="splash-texts">
          <div class="splash-name">AgroApp</div>
          <div class="splash-tagline">Seleccioná tu propiedad</div>
        </div>
        <div class="propiedad-cards" id="propiedad-cards"></div>
      </div>
    `;
    document.body.prepend(screen);
  }
  screen.classList.remove('hidden', 'propiedad-hide');

  // Cerrar sidebar si está abierto
  document.getElementById('sidebar')?.classList.remove('open');
  document.getElementById('overlay')?.classList.remove('active');

  const empresa = await mostrarSelectorPropiedad(empresas);
  await mostrarSelectorUso(empresa);
  window.showView('hojas');
}

window.cambiarPropiedad = cambiarPropiedad;

function actualizarHeaderPropiedad(nombre) {
  const header = document.querySelector('.header-title');
  if (header) header.textContent = `🌱 ${nombre}`;
  const sidebarBtn = document.getElementById('sidebar-propiedad-nombre');
  if (sidebarBtn) sidebarBtn.textContent = nombre;
}

/* ===============================
   NAVEGACIÓN
================================ */
function showView(view, param = null) {
  document
    .querySelectorAll('section[id^="view-"]')
    .forEach(v => v.classList.add('hidden'));

  const section = document.getElementById(`view-${view}`);
  if (section) section.classList.remove('hidden');

  switch (view) {
    case 'empresas':
      cargarEmpresas();
      break;

    case 'cultivos':
      initCultivosView();
      cargarCultivos();
      break;

    case 'tecnicos':
      initTecnicosView();
      cargarTecnicos();
      break;

    case 'caudales':
      initCaudalesView();
      cargarCaudales();
      break;
    
    case 'sectores':
      initSectoresView();
      break;
    
    case 'lotes':
      initLotesView();
      cargarVistaLotes();
      break;
    
    case 'variedades':
      initVariedadesView();  // 👈 faltaba esto
      cargarVistaVariedades();
      break;

    case 'productos':
      initProductosView();
      cargarProductos();
      break;  

    case 'tipos-producto':
      initTiposProductoView();
      cargarTiposProducto();
      break;

    case 'tipos-aplicacion':
      initTiposAplicacionView();
      cargarTiposAplicacion();
      break;

    case 'unidades':
      initUnidadesMedidaView();
      cargarUnidadesMedida();
      break;

    case 'hoja-detalle':
      initHojaDetalleView();
      if (param) cargarHojaDetalle(param);
      break;

    case 'hojas':
      initHojasView();
      cargarHojas();
      break;

    case 'nueva-hoja':
      initNuevaHojaView();
      cargarNuevaHoja();
      break; 
    
    case 'editar-hoja':
      initHojaEditarView();
      if (param) cargarHojaEditar(param);
      break;

    case 'importacion':
      initImportacionView();
      cargarImportacion();
      break;
  }
}

// 👇 DEBE IR AQUÍ, después de definir showView
window.showView = showView;

document.querySelectorAll('[data-view]').forEach(link => {
  link.addEventListener('click', e => {
    e.preventDefault();
    showView(link.dataset.view);
  });
});

/* ===============================
   NAVEGACIÓN CON HISTORIAL (BACK)
================================ */
const _historial = [];
let _vistaActual = 'hojas';
let _paramActual = null;
window._backPresionado = false;

const _showViewOriginal = showView;
window.showView = function(view, param = null) {
  if (view !== _vistaActual) {
    _historial.push({ view: _vistaActual, param: _paramActual });
  }
  _vistaActual = view;
  _paramActual = param;
  _showViewOriginal(view, param);
};

function _manejarBack() {
  const modales = [...document.querySelectorAll('.modal')]
    .filter(m => !m.classList.contains('hidden') && m.offsetParent !== null);
  
  console.log('[BACK] modales abiertos:', modales.map(m => m.id));
  console.log('[BACK] historial:', _historial.length);
  console.log('[BACK] backPresionado:', _backPresionado);

  if (modales.length > 0) {
    modales[0].classList.add('hidden');
    return;
  }

  if (_historial.length > 0) {
    const anterior = _historial.pop();
    _vistaActual = anterior.view || 'hojas';
    _paramActual = anterior.param;
    _showViewOriginal(_vistaActual, _paramActual);
    return;
  }

  if (_backPresionado) {
    try { window.Capacitor.Plugins.App.exitApp(); } catch(e) {}
    try { navigator.app.exitApp(); } catch(e) {}
    try { window.close(); } catch(e) {}
    return;
  }

  window._backPresionado = true;
  const toast = document.createElement('div');
  toast.textContent = 'Presioná atrás de nuevo para salir';
  toast.style.cssText = `
    position:fixed; bottom:5rem; left:50%; transform:translateX(-50%);
    background:rgba(30,61,30,0.92); color:#fff; padding:0.6rem 1.2rem;
    border-radius:2rem; font-size:0.85rem; z-index:9999;
    box-shadow:0 4px 16px rgba(0,0,0,0.3);
  `;
  document.body.appendChild(toast);
  setTimeout(() => {
    window._backPresionado = false;
    toast.remove();
  }, 2500);
}

window._manejarBack = _manejarBack;

// Solo un listener — MainActivity.java llama window._manejarBack() directamente
// Los eventos de abajo son solo fallback para desarrollo en navegador
if (!window.Capacitor?.isNativePlatform?.()) {
  document.addEventListener('backbutton', _manejarBack, false);
}

/* ===============================
   START
================================ */
initApp();